<?php
function add_user($login , $password, $statut, $bdd)
{
	if ($requete = $bdd->prepare("INSERT INTO utilisateurs (login, password, statut) VALUES (".$login.",".$password.",".$statut");"))
	{
		return true;
	}
	else
	{
		return false;
	}
}

function info_exist($login, $bdd)
{
	$requete = $bdd->prepare("SELECT COUNT(*) FROM utilisateurs WHERE login = ".$pseudo.");");
		if ($requete = 0)
		{
			return false;
		}
		else
		{
			return true;
		}
}

?>