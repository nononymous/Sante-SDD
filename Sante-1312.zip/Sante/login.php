<?php

require('sql.php');
session_start();

if (isset($_POST['submit']))
{
	$query = $bdd->prepare("SELECT * FROM users WHERE login = :login");
	$query->bindValue(':login', $_POST['login'], PDO::PARAM_STR);
	$query->execute();
	$data = $query->fetch();
	
	if (($data['password']) == (sha1($_POST['password'])))
	{
		$_SESSION['status'] = $data['status'];
		$_SESSION['last_name'] = $data['last_name'];
		$_SESSION['first_name'] = $data['first_name'];
		$_SESSION['login'] = $data['login'];
		$_SESSION['social_security'] = $data['social_security'];

		if ($data['status'] == "Administrateur")
		{
			header('Location: administrateur.php');
		}

		else if ($data['status'] == "Patient")
		{
			header('Location: patient.php');
		}

		else if ($data['status'] == "Médecin")
		{
			header('Location: medecin.php');
		}

		else if ($data['status'] == "Pharmacie")
		{
			header('Location: pharmacie.php');
		}
	}

	else
	{
		?>  
		<script>
			alert('Identifiant ou mot de passe incorrect.'); 
			window.location.href = "index.php";
		</script>
		<?php
	}

	$requete->CloseCursor();
}

?>