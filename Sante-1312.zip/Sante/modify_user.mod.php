<?php
require('sql.php');

function read_data($bdd)
{
	$req = $bdd->prepare('SELECT social_security, first_name, last_name, birth_date, email, login, status FROM users');
	$req->execute();
	
	if ($req->rowCount() >= 1)
	{
		return $req;
	}

	else
	{
		return false;
	}
}

function read_own_data($social_security, $bdd)
{
	$req = $bdd->prepare('SELECT social_security, first_name, last_name, birth_date, email, login, status FROM users WHERE social_security = :social_security');
	$req->execute(array("social_security"=>$social_security));
	
	if ($req->rowCount() == 1)
	{
		return $req;
	}

	else
	{
		return false;
	}
}

function modify_user($social_security, $status, $last_name, $first_name, $birth_date, $email, $login, $bdd)
{
	$req = $bdd->prepare('UPDATE users SET social_security = :social_security, status = :status, last_name = :last_name, first_name = :first_name, birth_date = :birth_date, email = :email, login = :login WHERE social_security = :social_security');
	$req->execute(array("social_security"=>$social_security, "status"=>$status, "last_name"=>$last_name, "first_name"=>$first_name, "birth_date"=>$birth_date, "email"=>$email, "login"=>$login));
	return $req;
}

function delete_user($social_security, $bdd)
{
	$req = $bdd->prepare('DELETE FROM users WHERE social_security = :social_security');
	$req->execute(array("social_security"=>$social_security));
	return $req;
}

function modify_password($social_security, $password, $bdd)
{
	$req = $bdd->prepare('UPDATE users SET password = :password WHERE social_security = :social_security');
	$req->execute(array("social_security"=>$social_security, "password"=>$password));
	return $req;
}
