<?php
session_start();
require ("modify_user.mod.php");

if (isset($_POST["submit"]))
{
	if (sha1($_POST['new_password']) != sha1($_POST['confirm_password']))
	{
		?>  
		<script>
			alert('Les mots de passe ne sont pas identiques.'); 
			window.location.href = "modify_password.php";
		</script>
		<?php
	}

	else if (sha1($_POST['new_password']) == sha1($_POST['confirm_password']))
	{
		modify_password($_SESSION['social_security'], sha1($_POST['new_password']),$bdd);
		?>  
		<script>
			alert('Le mot de passe a été modifié.'); 
			window.location.href = "modify_password.php";
		</script>
		<?php
	}
}