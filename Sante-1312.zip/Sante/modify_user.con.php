<?php
require('modify_user.mod.php');

$req = read_data($bdd);

require('modify_user.view.php');
