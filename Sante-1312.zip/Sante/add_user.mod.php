<?php
require('sql.php');

function info_exist($login, $bdd)
{
	$req = $bdd->prepare('SELECT count(*) FROM users WHERE login = :login');
	$req->execute(array("login"=>$login));

	if ($req->fetch()[0] == 1)
	{
		return true;
	}

	else
	{
		return false;
	}
}

function add_user($social_security, $status, $last_name, $first_name, $birth_date, $email, $login, $password, $bdd)
{
	if (!info_exist($login, $bdd))
	{
		$req = $bdd->prepare('INSERT INTO users(social_security, status, first_name, last_name, birth_date, email, login, password) VALUES(:social_security, :status, :first_name, :last_name, :birth_date, :email, :login, :password)');
		$req->execute(array("social_security"=>$social_security, "status"=>$status, "first_name"=>$first_name, "last_name"=>$last_name, "birth_date"=>$birth_date, "email"=>$email, "login"=>$login, "password"=>sha1($password)));
		return true;
	}

	else
	{
		return false;
	}
}
