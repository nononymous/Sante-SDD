<?php
require('sql.php');

function add_patient($social_security, $last_name, $first_name, $birth_date, $email, $blood_group, $height, $weight, $vaccine, $doctor, $bdd)
{
	$req = $bdd->prepare('INSERT INTO patients(social_security, last_name, first_name, birth_date, email, blood_group, height, weight, vaccine, doctor) VALUES(:social_security, :last_name, :first_name, :birth_date, :email, :blood_group, :height, :weight, :vaccine, :doctor)');
		$req->execute(array("social_security"=>$social_security, "last_name"=>$last_name, "first_name"=>$first_name, "birth_date"=>$birth_date, "email"=>$email, "blood_group"=>$blood_group, "height"=>$height, "weight"=>$weight, "vaccine"=>$vaccine, "doctor"=>$doctor));
		return $req;
}
