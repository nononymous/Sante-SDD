<?php
require('sql.php');

function read_prescriptions($doctor, $bdd)
{
	$req = $bdd->prepare('SELECT * FROM prescription WHERE doctor = :doctor');
	$req->execute(array("doctor"=>$doctor));
	
	if ($req->rowCount() >= 1)
	{
		return $req;
	}

	else
	{
		return false;
	}
}

function read_id_prescriptions($id, $bdd)
{
	$req = $bdd->prepare('SELECT * FROM prescription WHERE id = :id');
	$req->execute(array("id"=>$id));
	
	if ($req->rowCount() >= 1)
	{
		return $req;
	}

	else
	{
		return false;
	}
}

function modify_prescription($id, $name, $taking, $duration, $social_security, $bdd)
{
	$req = $bdd->prepare('UPDATE prescription SET id = :id, name = :name, taking = :taking, duration = :duration, social_security = :social_security, date_prescription = :date_prescription');
	$req->execute(array("id"=>$id, "name"=>$name, "taking"=>$taking, "duration"=>$duration, "social_security"=>$social_security, "date_prescription"=>date("Y-m-d")));
	return $req;
}

function delete_prescription($id, $bdd)
{
	$req = $bdd->prepare('DELETE FROM prescription WHERE id = :id');
	$req->execute(array("id"=>$id));
	return $req;
}
