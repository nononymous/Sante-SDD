<?php
require('modify_patient.mod.php');

if (isset($_POST['submit']))
{
	modify_patient($_POST['social_security'], $_POST['last_name'], $_POST['first_name'], $_POST['birth_date'], $_POST['email'], $_POST['blood_group'], $_POST['height'], $_POST['weight'], $_POST['vaccine'], $bdd);
	?>  
		<script>
			alert("Le patient a été modifié."); 
			window.location.href = "modify_patient.view.php";
		</script>
	<?php
}