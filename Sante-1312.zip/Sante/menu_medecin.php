<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="rose" data-background-color="black" data-image="assets/img/sidebar-1.jpg">
      <div class="sidebar-wrapper">
        <div class="user">
          <div class="photo">
            <img src="assets/img/user.png" />
          </div>
          <div class="user-info">
            <a data-toggle="collapse" href="#collapseExample" class="username">
              <span class="username">
                Médecin
                <b class="caret"></b>
              </span>
            </a>
            <div class="collapse" id="collapseExample">
              <ul class="nav">
                <li class="nav-item">
                  <a class="nav-link" href="modify_password.php">
                    <span class="sidebar-mini"> MDP </span>
                    <span class="sidebar-normal"> Modifier mon mot de passe </span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <ul class="nav">
          <li class="nav-item ">
            <a class="nav-link" href="view_patients.php">
              <i class="material-icons"> visibility </i>
              <p> Visualiser Patients </p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="add_patient.view.php">
              <i class="material-icons"> add </i>
              <p> Ajouter Patient </p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="modify_patient.view.php">
              <i class="material-icons"> create </i>
              <p> Modifier Patient </p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="delete_patient.view.php">
              <i class="material-icons"> clear </i>
              <p> Supprimer Patient </p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="view_prescriptions.php">
              <i class="material-icons"> visibility </i>
              <p> Visualiser Ordonnances </p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="add_prescription.view.php">
              <i class="material-icons"> add </i>
              <p> Ajouter Ordonnance </p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="modify_prescription.view.php">
              <i class="material-icons"> create </i>
              <p> Modifier Ordonnance </p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="delete_prescription.view.php">
              <i class="material-icons"> clear </i>
              <p> Supprimer Ordonnance </p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="assets/img/certificat_medical.pdf">
              <i class="fa fa-user-md"> </i>
              <p> Certificat Médical </p>
            </a>
          </li>
        </ul> 
      </div>
    </div>
    <div class="main-panel">
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top " id="navigation-example">
        <div class="container-fluid">
          <div class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="logout.php">
                  <img src="assets/img/logout.png" alt="Logo" width=35px>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>