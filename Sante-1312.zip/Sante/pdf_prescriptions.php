<?php
require('fpdf181/fpdf.php');
require('sql.php');

class PDF extends FPDF
{
	function Header()
	{
	    // Police Arial gras 15
	    $this->SetFont('Arial','B',15);
	    // Right
	    $this->Cell(60);
	    // Titre
	    $this->Cell(70,20,'Ordonnance',1,0,'C');
	    // Saut de ligne
	    $this->Ln(30);
	}

	function Footer()
	{
		// Positionnement à 1,5 cm du bas
	    $this->SetY(-15);
	    // Police Arial italique 8
	    $this->SetFont('Arial','I',8);
	}
}

if (isset($_GET['id']))
{
	$req = $bdd->prepare('SELECT * from prescription, patients WHERE id = :id AND prescription.social_security = patients.social_security');
	$req->execute(array("id"=>$_GET['id']));
}

$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Times', 'B', 12);

while ($data = $req->fetch())
{
	$pdf->cell(0, 10, "Nom : " . $data['last_name'], 0, 1);
	$pdf->cell(0, 10, "Prenom : " . $data['first_name'], 0, 1);
	$pdf->cell(0, 10, "Date de naissance : " . date("d/m/Y", strtotime($data['birth_date'])), 0, 1);
	$pdf->cell(0, 10, "Securite sociale : " . $data['social_security'], 0, 1);
	$pdf->cell(0, 10, "---------------------------------------------------------------------------------------------------------------", 0, 1);
	$pdf->cell(0, 10, "Medicaments : " . $data['name'], 0, 1);
	$pdf->cell(0, 10, "Prise : " . $data['taking'], 0, 1);
	$pdf->cell(0, 10, "Duree : " . $data['duration'], 0, 1);
	$pdf->cell(0, 10, "Faite le : " . date("d/m/Y", strtotime($data['date_prescription'])), 0, 1);
}

$pdf->Output();
