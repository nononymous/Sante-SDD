<?php
require('modify_prescription.mod.php');

if (isset($_POST['submit']))
{
	modify_prescription($_POST['id'], $_POST['name'], $_POST['taking'], $_POST['duration'], $_POST['social_security'], $bdd);
	?>  
		<script>
			alert("L'ordonnance a été modifié.");
			window.location.href = "modify_prescription.view.php"; 
		</script>
	<?php
}
