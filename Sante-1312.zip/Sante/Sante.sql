-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le :  jeu. 13 déc. 2018 à 15:48
-- Version du serveur :  10.1.25-MariaDB
-- Version de PHP :  5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `Sante`
--

-- --------------------------------------------------------

--
-- Structure de la table `patients`
--

CREATE TABLE `patients` (
  `social_security` char(15) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `birth_date` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `blood_group` varchar(25) NOT NULL,
  `height` float NOT NULL,
  `weight` float NOT NULL,
  `vaccine` varchar(250) NOT NULL,
  `doctor` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `patients`
--

INSERT INTO `patients` (`social_security`, `first_name`, `last_name`, `birth_date`, `email`, `blood_group`, `height`, `weight`, `vaccine`, `doctor`) VALUES
('123456789123456', 'f', 'd', '2018-12-08', 'a@h.fr', 'B+', 0, 0, '', 'médecin'),
('123456789123457', 'test', 'ok', '1996-03-15', 'x@h.fr', 'O-', 1.56, 74.3, 'niquel', 'médecin'),
('123456789123459', 'x', 'x', '1111-11-11', 'a@h.fr', 'B-', 0, 0, '', 'demo'),
('x', 'x', 'x', '2018-12-13', 'x', 'x', 0, 0, 'x', 'test');

-- --------------------------------------------------------

--
-- Structure de la table `prescription`
--

CREATE TABLE `prescription` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `taking` varchar(50) NOT NULL,
  `duration` varchar(50) NOT NULL,
  `doctor` varchar(100) NOT NULL,
  `social_security` char(15) NOT NULL,
  `date_prescription` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `prescription`
--

INSERT INTO `prescription` (`id`, `name`, `taking`, `duration`, `doctor`, `social_security`, `date_prescription`) VALUES
(6, 'Doliprane', '2 fois par jour', '40 jours', 'médecin', '123456789123456', '2018-12-08'),
(7, 'TEST', '2 fois', '2 jours', 'médecin', '123456789123457', '2018-12-08');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `social_security` char(15) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `birth_date` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`social_security`, `first_name`, `last_name`, `birth_date`, `email`, `login`, `password`, `status`) VALUES
('037403740374374', 'x', 'x', '1999-02-11', 'a@h.fr', 'pharmacie', '3b004ac6d8a602681f5ee3587c924855679e21d9', 'Pharmacie'),
('123456789123452', 'Ok', 'Ok', '2001-01-01', 'x@f.fr', 'médecin', '3b004ac6d8a602681f5ee3587c924855679e21d9', 'Médecin'),
('123456789123453', 'x', 'x', '2018-12-05', 'a@h.fr', 'neyney', '3b004ac6d8a602681f5ee3587c924855679e21d9', 'Administrateur'),
('123456789123456', 'x', 'x', '1111-11-11', 'a@h.fr', 'patient', '3b004ac6d8a602681f5ee3587c924855679e21d9', 'Patient');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`social_security`);

--
-- Index pour la table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`id`),
  ADD KEY `social_security` (`social_security`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`social_security`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `prescription`
--
ALTER TABLE `prescription`
  ADD CONSTRAINT `social_security` FOREIGN KEY (`social_security`) REFERENCES `patients` (`social_security`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
